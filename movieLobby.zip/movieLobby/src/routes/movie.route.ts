import { Router } from 'express';
import { getAllMovies, searchMovies, addMovie, updateMovie, deleteMovie } from '../controllers/movie.controller';
import authMiddleware from '../middleware/auth.middleware';

const router = Router();

router.get('/movies', getAllMovies);
router.get('/search', searchMovies);
router.post('/movies', authMiddleware, addMovie);
router.put('/movies/:id', authMiddleware, updateMovie);
router.delete('/movies/:id', authMiddleware, deleteMovie);

export default router;
