import express from "express";
import movieRoutes from "./movie.route"

const router = express.Router();

class ApiRoutes {
    static routes() {
        router.use("/", movieRoutes);
        return router
    }
}

export default ApiRoutes.routes()