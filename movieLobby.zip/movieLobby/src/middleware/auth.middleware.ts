import { Request, Response, NextFunction } from 'express';

const authMiddleware = (req: Request, res: Response, next: NextFunction) => {
    const role = req.headers['role'];
    if (role === 'admin') {
        next();
    } else {
        res.status(403).send({ message: 'Forbidden' });
    }
};

export default authMiddleware;
