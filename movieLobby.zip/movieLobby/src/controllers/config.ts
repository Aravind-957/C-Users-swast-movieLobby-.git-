// src/config.ts
import dotenv from 'dotenv';
import path from 'path';

// Load environment variables from .env file
dotenv.config({ path: path.resolve(__dirname, '../.env') });

// Export variables
export const DB_URI = process.env.DB_URI;
export const PORT = process.env.PORT;
