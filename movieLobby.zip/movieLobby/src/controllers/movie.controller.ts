import { Request, Response } from 'express';
import movie from '../model/movie';

export const getAllMovies = async (req: Request, res: Response) => {
    const movies = await movie.find();
    res.json(movies);
};

export const searchMovies = async (req: Request, res: Response) => {
    const query = req.query.q as string;
    const movies = await movie.find({
        $or: [{ title: { $regex: query, $options: 'i' } }, { genre: { $regex: query, $options: 'i' } }],
    });
    res.json(movies);
};

export const addMovie = async (req: Request, res: Response) => {
    const { title, genre, rating, streamingLink } = req.body;
    const newMovie = new movie({ title, genre, rating, streamingLink });
    await newMovie.save();
    res.status(201).json(newMovie);
};

export const updateMovie = async (req: Request, res: Response) => {
    const { id } = req.params;
    const { title, genre, rating, streamingLink } = req.body;
    const updatedMovie = await movie.findByIdAndUpdate(id, { title, genre, rating, streamingLink }, { new: true });
    res.json(updatedMovie);
};

export const deleteMovie = async (req: Request, res: Response) => {
    const { id } = req.params;
    await movie.findByIdAndDelete(id);
    res.status(204).send();
};
