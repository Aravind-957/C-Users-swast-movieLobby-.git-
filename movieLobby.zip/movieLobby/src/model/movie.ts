import { Schema, model } from 'mongoose';

interface IMovie {
    title: string;
    genre: string;
    rating: number;
    streamingLink: string;
}

const movieSchema = new Schema<IMovie>({
    title: { type: String, required: true },
    genre: { type: String, required: true },
    rating: { type: Number, required: true },
    streamingLink: { type: String, required: true },
});

const Movie = model<IMovie>('Movie', movieSchema);

export default Movie;
